﻿namespace ATM
{
    partial class ATM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ATM));
            this.enter = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.test = new System.Windows.Forms.Button();
            this.bottomLeft = new System.Windows.Forms.Button();
            this.topLeft = new System.Windows.Forms.Button();
            this.topRight = new System.Windows.Forms.Button();
            this.botomRight = new System.Windows.Forms.Button();
            this.titleLabel = new System.Windows.Forms.Label();
            this.subLabel = new System.Windows.Forms.Label();
            this.lblInfo = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // enter
            // 
            this.enter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.enter.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enter.Location = new System.Drawing.Point(288, 211);
            this.enter.MaximumSize = new System.Drawing.Size(60, 60);
            this.enter.MinimumSize = new System.Drawing.Size(60, 60);
            this.enter.Name = "enter";
            this.enter.Size = new System.Drawing.Size(60, 60);
            this.enter.TabIndex = 3;
            this.enter.Text = "Enter";
            this.enter.UseVisualStyleBackColor = false;
            this.enter.Click += new System.EventHandler(this.enter_Click);
            // 
            // clear
            // 
            this.clear.BackColor = System.Drawing.Color.Yellow;
            this.clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear.Location = new System.Drawing.Point(288, 277);
            this.clear.MaximumSize = new System.Drawing.Size(60, 60);
            this.clear.MinimumSize = new System.Drawing.Size(60, 60);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(60, 60);
            this.clear.TabIndex = 7;
            this.clear.Text = "Clear";
            this.clear.UseVisualStyleBackColor = false;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // cancel
            // 
            this.cancel.BackColor = System.Drawing.Color.Red;
            this.cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancel.Location = new System.Drawing.Point(288, 343);
            this.cancel.MaximumSize = new System.Drawing.Size(60, 60);
            this.cancel.MinimumSize = new System.Drawing.Size(60, 60);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(60, 60);
            this.cancel.TabIndex = 11;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = false;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // button0
            // 
            this.button0.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button0.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button0.Location = new System.Drawing.Point(81, 404);
            this.button0.MaximumSize = new System.Drawing.Size(215, 200);
            this.button0.MinimumSize = new System.Drawing.Size(60, 60);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(205, 70);
            this.button0.TabIndex = 12;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = false;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // test
            // 
            this.test.Location = new System.Drawing.Point(355, 443);
            this.test.Name = "test";
            this.test.Size = new System.Drawing.Size(67, 31);
            this.test.TabIndex = 13;
            this.test.Text = "Test";
            this.test.UseVisualStyleBackColor = true;
            this.test.Click += new System.EventHandler(this.test_Click_1);
            // 
            // bottomLeft
            // 
            this.bottomLeft.Location = new System.Drawing.Point(0, 128);
            this.bottomLeft.Name = "bottomLeft";
            this.bottomLeft.Size = new System.Drawing.Size(65, 65);
            this.bottomLeft.TabIndex = 15;
            this.bottomLeft.UseVisualStyleBackColor = true;
            // 
            // topLeft
            // 
            this.topLeft.Location = new System.Drawing.Point(0, 10);
            this.topLeft.Name = "topLeft";
            this.topLeft.Size = new System.Drawing.Size(65, 65);
            this.topLeft.TabIndex = 16;
            this.topLeft.UseVisualStyleBackColor = true;
            // 
            // topRight
            // 
            this.topRight.Location = new System.Drawing.Point(367, 10);
            this.topRight.Name = "topRight";
            this.topRight.Size = new System.Drawing.Size(65, 65);
            this.topRight.TabIndex = 17;
            this.topRight.UseVisualStyleBackColor = true;
            // 
            // botomRight
            // 
            this.botomRight.Location = new System.Drawing.Point(367, 128);
            this.botomRight.Name = "botomRight";
            this.botomRight.Size = new System.Drawing.Size(65, 65);
            this.botomRight.TabIndex = 18;
            this.botomRight.UseVisualStyleBackColor = true;
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.BackColor = System.Drawing.Color.MediumBlue;
            this.titleLabel.ForeColor = System.Drawing.Color.White;
            this.titleLabel.Location = new System.Drawing.Point(164, 36);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(108, 13);
            this.titleLabel.TabIndex = 19;
            this.titleLabel.Text = "Welcome to the ATM";
            // 
            // subLabel
            // 
            this.subLabel.AutoSize = true;
            this.subLabel.BackColor = System.Drawing.Color.MediumBlue;
            this.subLabel.ForeColor = System.Drawing.Color.White;
            this.subLabel.Location = new System.Drawing.Point(137, 154);
            this.subLabel.Name = "subLabel";
            this.subLabel.Size = new System.Drawing.Size(169, 13);
            this.subLabel.TabIndex = 20;
            this.subLabel.Text = "Please enter your account number";
            // 
            // lblInfo
            // 
            this.lblInfo.BackColor = System.Drawing.Color.MediumBlue;
            this.lblInfo.ForeColor = System.Drawing.Color.White;
            this.lblInfo.Location = new System.Drawing.Point(140, 89);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(166, 20);
            this.lblInfo.TabIndex = 21;
            // 
            // ATM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(434, 486);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.subLabel);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.botomRight);
            this.Controls.Add(this.topRight);
            this.Controls.Add(this.topLeft);
            this.Controls.Add(this.bottomLeft);
            this.Controls.Add(this.test);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.enter);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(450, 525);
            this.MinimumSize = new System.Drawing.Size(450, 525);
            this.Name = "ATM";
            this.Text = "ATM";
            this.Load += new System.EventHandler(this.ATM_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button enter;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button test;
        private System.Windows.Forms.Button bottomLeft;
        private System.Windows.Forms.Button topLeft;
        private System.Windows.Forms.Button topRight;
        private System.Windows.Forms.Button botomRight;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label subLabel;
        private System.Windows.Forms.TextBox lblInfo;
    }
}