﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace ATM
{
    public partial class ATM : Form
    {
        Button[] keypad;
        Button[,] btn = new Button[3, 3];
        Panel pinPanel = new Panel();
         

        public ATM()
        {
            InitializeComponent();
            setup();
            
        }

        void setup()
        {
            Graphics g = this.CreateGraphics();
            Pen selPen = new Pen(Color.MediumBlue);
            g.DrawRectangle(selPen, 10, 10, 50, 50);
            g.Dispose();
           
          


           // keypad = new Button[] { button0, button1, button2, button3, button4, button5, button6, button7, button8, button9, enter, clear, cancel };
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            Graphics g = e.Graphics;
            using (Pen selPen = new Pen(Color.MediumBlue))
            {
                g.DrawRectangle(selPen, 65, 10, 300, 180);
            }

            SolidBrush solidBrush = new SolidBrush(Color.MediumBlue);
            g.FillRectangle(solidBrush, 65, 10, 300, 180);
        }

        public void keypadVisible(bool x)
        {
            /* for (int i = 0; i < 13; i++)
             {
                 keypad[i].Visible = x;
             }*/

            pinPanel.Visible=x;
            button0.Visible=x;
            enter.Visible = x;
            cancel.Visible = x;
            clear.Visible=x;

        }

        //logic for checking the account against stored account numbers 
        public void accountCheck(bool x)
        {
            string check = lblInfo.Text;

            
        }

        public void pinNumberCheck()
        {
            if(lblInfo.Text.Length > 4)
            {
                //stop them from typing in and keep the values the same. 
            }
        }

        private void test_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Hiding...");
            keypadVisible(false);
            MessageBox.Show("Showing...");
            keypadVisible(true);
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ATM_Load(object sender, EventArgs e)
        {

            pinPanel.SetBounds(80, 200, 280, 274);
            pinPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            Controls.Add(pinPanel);
            int counter = 0;
            // Loops x amount of times until x is equal to the length in the array
            for (int y = 0; y < btn.GetLength(0); y++)
            {
                
                
                
                

                // Loops x amount of times until y is equal to the length in the array
                for (int x = 0; x < btn.GetLength(1); x++)     // Loop for y
                {
                    
                    //Creates a new button
                    btn[x, y] = new Button();

                    //Sets the position and size of each button
                    btn[x, y].SetBounds(65 * x, 65 * y, 75, 75);

                    //Creates an event handler. This will be used later in the program for events for each button.
                    btn[x, y].Click += new EventHandler(pinEvent_Click);
                    counter++;
                    btn[x, y].Text = Convert.ToString(counter);
                     
                    btn[x, y].Font = new Font("Microsoft Sans Serif", 20.25f );
                    pinPanel.Controls.Add(btn[x, y]);

                    
                }

                

            }

        }
        void pinEvent_Click(object sender, EventArgs e)
        {
            string number = (sender as Button).Text;
            lblInfo.Text += (number);
            if (lblInfo.Text.Length > 6)
            {
                MessageBox.Show("Account number is too long, please try again");
                lblInfo.Text = ("");
            }
        
        }

        private void enter_Click(object sender, EventArgs e)
        {
            
        }

        private void clear_Click(object sender, EventArgs e)
        {
            lblInfo.Text = ("");
        }

        private void button0_Click(object sender, EventArgs e)
        {
            string number = (sender as Button).Text;
            lblInfo.Text += (number);
            if (lblInfo.Text.Length>6)
            {
                MessageBox.Show("Account number is too long, please clear and try again.");
            }
            
 
        }
    }



}

